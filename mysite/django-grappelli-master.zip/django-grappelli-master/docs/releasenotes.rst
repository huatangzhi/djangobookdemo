:tocdepth: 1

.. |grappelli| replace:: Grappelli
.. |filebrowser| replace:: FileBrowser

.. _releasenotes:

Grappelli 2.5.x Release Notes
=============================

**Grappelli 2.5.x is compatible with Django 1.6**.

This release does not introduce any new features.

Update from Grappelli 2.4.x
---------------------------

* Update Django to 1.6 and check https://docs.djangoproject.com/en/dev/releases/1.6/
* Update Grappelli to 2.5.x